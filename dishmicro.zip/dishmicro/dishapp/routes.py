import os
# from urllib import request

from flask import url_for, redirect, render_template, flash, session, Response, request, make_response
from sqlalchemy import func
from werkzeug.security import generate_password_hash, check_password_hash
from dishapp import app, db, form
from dishapp.config import Config
from dishapp.form import LoginForm, SignupForm, ProfileForm, PostForm, SearchForm
from dishapp.models import User, Profile, Post


@app.route('/', methods=['GET', 'POST'])
def index():
    form = SearchForm()

    if form.validate_on_submit():
        session["TITLE"] = form.criteria.data
        return redirect(url_for('index'))
    if session.get("TITLE") is None:
        prev_posts = Post.query.all()
    else:
        t = session.get("TITLE")
        prev_posts = db.session.query(Post).filter(Post.title.like('%{0}%'.format(t))).all()
    if not session.get("USERNAME") is None:
        user_in_db = User.query.filter(User.username == session.get("USERNAME")).first()
        stored_profile = Profile.query.filter(Profile.user == user_in_db).first()
        return render_template("index.html", title="Index", form=form, prev_posts=prev_posts, profile=stored_profile)
    return render_template("index.html", title="Index", form=form, prev_posts=prev_posts)


# code is from week 7 page 31 and made several changes

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if not session.get("USERNAME") is None:
        flash("You have already login")
        return redirect(url_for('profile'))
    else:
        if form.validate_on_submit():
            user_in_db = User.query.filter(User.username == form.username.data).first()
            if not user_in_db:
                flash('No user found with username: {}'.format(form.username.data))
                return redirect(url_for('login'))
            else:
                check_password_hash(user_in_db.password_hash, form.password.data)
                flash('Login success!')
                session["USERNAME"] = user_in_db.username
                user_in_db = User.query.filter(User.username == session.get("USERNAME")).first()
                if Profile.query.filter(Profile.user == user_in_db).first():
                    stored_profile = Profile.query.filter(Profile.user == user_in_db).first()
                    if stored_profile.avatar:
                        session["AVATAR"] = stored_profile.avatar
                    else:
                        session["AVATAR"] = None
                else:
                    session["AVATAR"] = None
                return redirect(url_for('profile'))
    return render_template("login.html", title="Sign in", form=form)


# code is from week 7 page 31

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = SignupForm()
    if form.validate_on_submit():
        if form.password.data != form.password2.data:
            flash('PassWords do not match')
            return redirect(url_for('signup'))

        passw_hash = generate_password_hash(form.password.data)
        user = User(username=form.username.data, email=form.email.data, password_hash=passw_hash)
        db.session.add(user)
        db.session.commit()
        flash('User registered with username:{}'.format(form.username.data))
        return redirect(url_for('profile'))
    return render_template('signup.html', title='Register a new user', form=form)


# use some ideas form week8 page17
@app.route('/profile', methods=['GET', 'POST'])
def profile():
    form = ProfileForm()
    if not session.get("USERNAME") is None:
        if form.validate_on_submit():
            if not form.avatar.data is None:
                cv_dir = Config.Avatar_UPLOAD_DIR
                img = form.avatar.data
                filename = img.filename
                new_filename = session.get("USERNAME") + "." + filename.rsplit('.')[-1]
                img.save(os.path.join(cv_dir, new_filename))
                path = 'uploaded_Avatar/' + new_filename
                flash('CV uploaded and saved')
            user_in_db = User.query.filter(User.username == session.get("USERNAME")).first()
            stored_profile = Profile.query.filter(Profile.user == user_in_db).first()
            if not stored_profile:
                if not form.country.data is None and form.avatar.data is None:
                    profile = Profile(dob=form.dob.data, gender=form.gender.data, country=form.country.data,
                                      user=user_in_db)
                    db.session.add(profile)
                elif not form.country.data is None and not form.avatar.data is None:
                    profile = Profile(dob=form.dob.data, gender=form.gender.data, country=form.country.data,
                                      user=user_in_db,
                                      avatar=path)
                    session["AVATAR"] = path
                    db.session.add(profile)
                elif form.country.data is None and not form.avatar.data is None:
                    profile = Profile(dob=form.dob.data, gender=form.gender.data, user=user_in_db,
                                      avatar=path)
                    session["AVATAR"] = path
                    db.session.add(profile)
                else:
                    profile = Profile(dob=form.dob.data, gender=form.gender.data, user=user_in_db)
                    db.session.add(profile)
            else:
                stored_profile.dob = form.dob.data
                stored_profile.db = form.dob.data
                if not form.country.data is None:
                    stored_profile.country = form.country.data
                if not form.avatar.data is None:
                    stored_profile.avatar = path
                    session["AVATAR"] = path
            db.session.commit()
            return redirect(url_for('post'))
        else:
            user_in_db = User.query.filter(User.username == session.get("USERNAME")).first()
            stored_profile = Profile.query.filter(Profile.user == user_in_db).first()
            if not stored_profile:
                return render_template('profile.html', title='Add your profile', form=form,user=user_in_db)
            else:
                form.dob.data = stored_profile.dob
                form.gender.data = stored_profile.gender
                return render_template('profile.html', title='Modify your profile', form=form, user=user_in_db)

    else:
        flash("User needs to either login or signup first")
        return redirect(url_for('login'))


@app.route('/index/<id>', methods=['GET'])
def dish_detail(id):
    id = id.strip("<>")
    dish = Post.query.filter_by(id=id).first()
    return render_template('dish_detail.html', title='Dish_detail', dish=dish, id=id)


@app.route('/logout')
def logout():
    session.pop("USERNAME", None)
    return redirect(url_for('login'))


@app.route('/post', methods=['GET', 'POST'])
def post():
    form = PostForm()
    if not session.get("USERNAME") is None:
        if form.validate_on_submit():
            body = form.postbody.data
            title = form.posttitle.data
            user_in_db = User.query.filter(User.username == session.get("USERNAME")).first()
            post = Post(body=body, author=user_in_db, title=title)
            db.session.add(post)
            db.session.commit()
            return redirect(url_for('post'))
        else:
            user_in_db = User.query.filter(User.username == session.get("USERNAME")).first()
            prev_posts = Post.query.filter(Post.user_id == user_in_db.id).all()
            print("Checking for user: {} with id: {}".format(user_in_db.username, user_in_db.id))
            return render_template('post.html', title='User Posts', prev_posts=prev_posts, form=form)
    else:
        flash("User needs to either login or signup first")
        return redirect(url_for('login'))
